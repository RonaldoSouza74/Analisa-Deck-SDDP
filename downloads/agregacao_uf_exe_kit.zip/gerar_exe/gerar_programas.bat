@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo ============================================================
echo  GERAR OS PROGRAMAS (.exe) - rode UMA vez, aqui no Windows
echo ============================================================
echo.
echo Esta maquina precisa de Python instalado (qualquer versao 3.x) e internet.
echo Quem SO VAI USAR os programas depois NAO precisa de nada disso.
echo.
pause
echo.
echo [1 de 3] Instalando as ferramentas de geracao (demora so na primeira vez)...
python -m pip install --upgrade pyinstaller numpy matplotlib python-pptx
if errorlevel 1 goto erro
echo.
echo [2 de 3] Gerando o programa analisa.exe (pode levar varios minutos)...
if exist saida rmdir /s /q saida
python -m PyInstaller --noconfirm --clean --onedir --name analisa ^
  --paths fonte --collect-all pptx --collect-data matplotlib ^
  --distpath saida --workpath build_tmp --specpath build_tmp ^
  fonte\_main.py
if errorlevel 1 goto erro
echo.
echo [3 de 3] Copiando os rodar_*.bat, as tabelas e o mapa para junto do programa...
copy /y distribuir\*.* saida\analisa\ > nul
if exist build_tmp rmdir /s /q build_tmp
echo.
echo ============================================================
echo  PRONTO! A pasta para DISTRIBUIR aos usuarios e esta:
echo.
echo     %~dp0saida\analisa
echo.
echo  Compacte essa pasta (botao direito ^> Enviar para ^> pasta
echo  compactada) e mande para os usuarios. Eles so dao dois
echo  cliques nos arquivos rodar_*.bat, sem instalar nada.
echo ============================================================
echo.
pause
exit /b 0
:erro
echo.
echo Algo deu errado. Copie as mensagens acima e envie para analise.
pause
exit /b 1
