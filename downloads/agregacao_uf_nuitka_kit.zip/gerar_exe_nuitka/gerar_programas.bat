@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo ============================================================
echo  GERAR OS PROGRAMAS (.exe) - versao Nuitka (codigo nativo)
echo  Rode UMA vez, aqui no Windows.
echo ============================================================
echo.
echo Esta maquina precisa de Python (qualquer 3.x) e internet. O Nuitka vai
echo baixar sozinho um compilador C na primeira vez (pode demorar bastante).
echo Quem SO VAI USAR os programas depois NAO precisa de nada disso.
echo.
pause
echo.
echo [1 de 3] Instalando as ferramentas de geracao...
python -m pip install --upgrade nuitka ordered-set numpy matplotlib python-pptx
if errorlevel 1 goto erro
echo.
echo [2 de 3] Compilando para codigo nativo (pode levar de 10 a 40 minutos)...
if exist saida rmdir /s /q saida
python -m nuitka --standalone --assume-yes-for-downloads --remove-output ^
  --enable-plugin=no-qt ^
  --include-package-data=pptx --include-package-data=matplotlib ^
  --output-dir=saida --output-filename=analisa.exe ^
  fonte\_main.py
if errorlevel 1 goto erro
if exist saida\analisa rmdir /s /q saida\analisa
move saida\_main.dist saida\analisa > nul
echo.
echo [3 de 3] Copiando os rodar_*.bat, as tabelas e o mapa para junto do programa...
copy /y distribuir\*.* saida\analisa\ > nul
if not exist "saida\analisa\pptx\oxml" mkdir "saida\analisa\pptx\oxml"
echo.
echo ============================================================
echo  PRONTO! A pasta para DISTRIBUIR aos usuarios e esta:
echo.
echo     %~dp0saida\analisa
echo.
echo  Compacte essa pasta e mande para os usuarios. Eles so dao
echo  dois cliques nos rodar_*.bat, sem instalar nada.
echo  O codigo Python NAO vai junto e nao pode ser recuperado dela.
echo ============================================================
echo.
pause
exit /b 0
:erro
echo.
echo Algo deu errado. Copie as mensagens acima e envie para analise.
pause
exit /b 1
